﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parte1atividade4
{
    public partial class parte1 : Form
    {
        public parte1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double valor, total;
            int dias;
            valor = Double.Parse(txtvalor.Text);
            dias = int.Parse(txtdias.Text);

            total = 8.49 + ((valor * 0.0005) * dias) + valor;

            MessageBox.Show("O total a pagar é "+total);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
