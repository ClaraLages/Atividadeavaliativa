﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parte1atividade4
{
    public partial class parte2 : Form
    {
        public parte2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int mes;
            mes = int.Parse(txtmes.Text);

            if (mes == 1)
            {
                MessageBox.Show("Mes" + mes + "é janeiro");
            }
            else if (mes == 2)
            {
                MessageBox.Show("Mes" + mes + "é fevereiro");
            }
            else if (mes == 3)
            {
                MessageBox.Show("Mes" + mes + "é março");
            }
            else if (mes == 4)
            {
                MessageBox.Show("Mes" + mes + "é abril");
            }
            else if (mes == 5)
            {
                MessageBox.Show("Mes" + mes + "maio");
            }
            else if (mes == 6)
            {
                MessageBox.Show("Mes" + mes + "é junho");
            }
            else if (mes == 7)
            {
                MessageBox.Show("Mes" + mes + "é julho");
            }
            else if (mes == 8)
            {
                MessageBox.Show("Mes" + mes + "é agosto");
            }
            else if (mes == 9)
            {
                MessageBox.Show("Mes" + mes + "setembro");
            }
            else if (mes == 10)
            {
                MessageBox.Show("Mes" + mes + "é outubro");
            }
            else if (mes == 11)
            {
                MessageBox.Show("Mes" + mes + "é novembro");
            }
            else if (mes == 12)
            {
                MessageBox.Show("Mes" + mes + "é dezembro");
            }
            else
            {
                MessageBox.Show("Valor não compativel");
            }
        }
    }
}
