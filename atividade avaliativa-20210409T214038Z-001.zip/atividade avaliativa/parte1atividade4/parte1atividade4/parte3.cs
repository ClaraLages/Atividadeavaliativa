﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parte1atividade4
{
    public partial class parte3 : Form
    {
        public parte3()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nome;
            int diaria, total;
            nome = txtnome.Text;
            diaria = int.Parse(txtdiaria.Text);

            if(diaria > 15)
            {
                total = diaria * 10;
                MessageBox.Show("Ola " +nome+ " seu total é de " +total );
            }else if(diaria == 15)
            {
                total = diaria * 12;
                MessageBox.Show("Ola "+nome+" seu total é de " + total );
            }
            else if (diaria < 15)
            {
                total = diaria * 15;
                MessageBox.Show("Ola "+nome+" seu total é de " + total );
            }
        }
    }
}
